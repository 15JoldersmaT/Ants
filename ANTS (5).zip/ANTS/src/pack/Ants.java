package pack;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Ants extends JPanel implements ActionListener {
    private Timer timer;
    public static List<Being> beings = new ArrayList<>();
    public static List<Scent> scents = new ArrayList<>();
    public static List<Food> foods = new ArrayList<>();
    public static List<Hill> hills = new ArrayList<>();

    private  static int DELAY = 15; // Milliseconds between update/render calls
    
    public static boolean paused = false;
    
    
    private static final Random rand = new Random();

    public static int mX, mY = 0;

    public static int selectedTile = 0;
    public Ants() {
        setPreferredSize(new Dimension(1000, 800));
        setBackground(Color.BLACK);
        initGame();
    }

    private void initGame() {
    	
        Color c = new Color(rand.nextInt(155),rand.nextInt(155),rand.nextInt(155));
        for (int i = 0;i<10;i++) {
        	if (i == 0) {
        		c = new Color(255, 20, 60);
        	}else if (i == 1) {
        		c = new Color(30, 144, 255);

        	}else if (i == 2) {
        		c = new Color(255, 215, 0);

        	}else if (i == 3) {
        		c = new Color(34, 139, 34);

        	}else if (i == 4) {
        		c = new Color(255, 234, 0);


        	}else if (i == 6) {
        		c = new Color(225, 40, 147);

        	}
        	else if (i == 7) {
        		c = new Color(128, 128, 128);

        	}
        	Hill h = new Hill(new Color(rand.nextInt(155),rand.nextInt(155),rand.nextInt(155)),rand.nextInt(1000), rand.nextInt(800));
        	hills.add(h);
        }
        
        
        for (int i = 0;i<300;i++) {
        	Food f = new Food(rand.nextInt(1000), rand.nextInt(800));
        	foods.add(f);
        }
        timer = new Timer(100, this);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        
        for (Food food : foods) {
            food.draw(g2d);
            
        }
        for (Hill hill : hills) {
            hill.draw(g2d);
            
        }
        
        for (Scent scent: scents) {
            scent.draw(g2d);
            
        }
        
        
        for (Being being : beings) {
            being.draw(g2d);
            
        }
     // Example of adding text to the screen
        if (paused) {
            g2d.setColor(Color.WHITE); // Set the text color
            g2d.setFont(new Font("Arial", Font.BOLD, 24)); // Set the font
            g2d.drawString("Game Paused", 850, 100); // Draw the string
        }
        
        // Optionally, you can display other information in a similar manner
        // For example, showing coordinates when debugging
        g2d.setColor(Color.YELLOW);
        g2d.setFont(new Font("Arial", Font.PLAIN, 12));
        //g2d.drawString("Mouse X: " + mX + ", Mouse Y: " + mY, 10, 700);
        
        int yS = 10;
        
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
    }

    private void updateGame() {
    
    		for (int i = 0;i<beings.size();i++) {
        		beings.get(i).update();
        	}
    		for (int i = 0;i<hills.size();i++) {
        		hills.get(i).update();
        	}
    		for (int i = 0;i<scents.size();i++) {
        		scents.get(i).update();
        	}
    		
        repaint();
    }

 

    public static void main(String[] args) {
    	
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Ants!");
            Ants gamePanel = new Ants();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(gamePanel);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
            frame.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                	
                	if (e.getKeyCode() == KeyEvent.VK_P) { // If 'R' key is pressed
                		
                        	if(paused == false) {
                        		paused = true;
                        	}else {
                        		paused = false;
                        	}
                 
                    }
                	
                }
            });
            frame.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    mX = e.getX();
                    mY = e.getY();
                    Food f = new Food(mX - 15, mY - 40);
                    foods.add(f);
                }
            });
        });
    }
}