package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

public class Spider extends Being {
	private int x, y; // Spider's position
    private final int baseSize = 20; // Base size of the spider's body
    private double scale = .5; // Initial scale factor
    
	public Spider(Color c, int x, int y) {
		super(c, x, y);
		this.x = x;
		this.y = y;
		c = new Color(100,0,0);
	}
	
	public void draw(Graphics2D g2d) {
	    int bodyWidth = (int) (30 * scale);
	    int bodyHeight = (int) (20 * scale);
	    int headSize = (int) (10 * scale);

	    // Spider's body
	    g2d.setColor(new Color(200,100,50)); // Consider a dark color for the spider
	    g2d.fillOval(x - bodyWidth / 2, y - bodyHeight / 2, bodyWidth, bodyHeight);

	    // Spider's head
	    g2d.fillOval(x - headSize / 2, y - bodyHeight / 2 - headSize / 2, headSize, headSize);

	    // Legs
	    g2d.setColor(new Color(125, 0, 60));
	    int legLength = (int) (bodyWidth * 0.75);
	    int legThickness = (int) (.4 * scale);
	    g2d.setStroke(new BasicStroke(legThickness));

	    // Drawing 4 legs on each side
	    for (int i = 0; i < 4; i++) {
	        // Calculating the starting points (x, y) for each leg
	        int startX =  x - bodyWidth / 8 + (bodyWidth / 4) * i / 4;
	        int startY = y ;

	        // Upper legs (right side)
	        g2d.drawLine(startX, startY, startX + legLength / 2, startY - legLength);
	        g2d.drawLine(startX + legLength / 2, startY - legLength, startX + legLength, startY + 10);

	        // Lower legs (left side)
	        g2d.drawLine(startX, startY, startX - legLength / 2, startY - legLength);
	        g2d.drawLine(startX - legLength / 2, startY - legLength, startX - legLength, startY + 10);
	    }
	}
	
	public void update() {
		int mC = rand.nextInt(300);
		if (mC == 0) {
			setMoveCode("Left");
		}
		else if(mC == 1) {
			setMoveCode("Right");

		}
		else if(mC == 2) {
			setMoveCode("Down");
		
		}
		else if(mC == 3) {
			setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}	
		
		if (this.getMoveCode() == "Left") {
			this.x -= 1;

		}else if(this.getMoveCode() == "Right") {
			this.x += 1;

		}
		else if(this.getMoveCode() == "Down") {
			this.y += 1;

		}
		else if(this.getMoveCode() == "Up") {
			this.y -= 1;

		}
		else if(this.getMoveCode() == "LeftUp") {
			this.y -= 1;
			this.x -= 1;


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.x -= 1;
			this.y += 1;

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.x += 1;
			this.y -= 1;
		}
		else if(this.getMoveCode() == "RightDown") {
			this.x += 1;
			this.y += 1;
		}
		
		for (int i = 0;i<Ants.beings.size();i++) {
			double oX = Ants.beings.get(i).getX();
	        double oY = Ants.beings.get(i).getY();
	
	        double dX = this.x - oX;
	        double dY = this.y - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
	        
	        if(dist < 35 && Ants.beings.get(i)!= this) {
	        	if (this.x < Ants.beings.get(i).getX()) {
	        		this.x += 12;
	        	}
	        	
	        	if (this.x > Ants.beings.get(i).getX()) {
	        		this.x -= 12;
	        	}
	        	
	        	if (this.y < Ants.beings.get(i).getY()) {
	        		this.y += 12;
	        	}
	        	
	        	if (this.y > Ants.beings.get(i).getY()) {
	        		this.y -= 12;
	        	}
	        }
	        try {
	     
	        
		        if(dist <35 && Ants.beings.get(i)!= this) {
		         double t =rand.nextDouble(5 - this.scale);
		         if (t <= 1) {
		        	Ants.beings.remove(i);
		        	if(this.scale < 4) {
			        	this.scale += .25;
		        	}
		         }
		        	
		        }
	        }catch(Exception e) {
	        	
	        }
	        if (this.x < 0) {
				this.x = 0;
			}
			if (this.x > 1000) {
				this.x = 1000;
			}
			if (this.y < 0) {
				this.y = 0;
			}
			if(this.y > 800) {
				this.y = 800;
			}
		}
	}

}
