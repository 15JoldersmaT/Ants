package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;

public class Mantis extends Being{
	private int x, y; // Position of the Praying Mantis
    private double scale; // Scale factor for the Praying Mantis 
    private boolean swarmed = false;
	public Mantis(Color c, int x, int y) {
		super(c, x, y);
		this.x = x;
        this.y = y;
        this.scale = .2;
        c = new Color(0,0,0);
	}
	
	
	public void draw(Graphics2D g2d) {
		// Basic settings
        g2d.setColor(Color.GREEN.darker());
        g2d.setStroke(new BasicStroke(2));

        // Body
        Ellipse2D.Double body = new Ellipse2D.Double(x - 15 * scale, y, 30 * scale, 80 * scale);
        g2d.fill(body);

        // Head
        Ellipse2D.Double head = new Ellipse2D.Double(x - 10 * scale, y - 20 * scale, 20 * scale, 20 * scale);
        g2d.fill(head);

        // Eyes
        g2d.setColor(Color.WHITE);
        Ellipse2D.Double leftEye = new Ellipse2D.Double(x - 8 * scale, y - 18 * scale, 8 * scale, 12 * scale);
        Ellipse2D.Double rightEye = new Ellipse2D.Double(x, y - 18 * scale, 8 * scale, 12 * scale);
        g2d.fill(leftEye);
        g2d.fill(rightEye);

        // Pupils
        g2d.setColor(Color.RED);
        Ellipse2D.Double leftPupil = new Ellipse2D.Double(x - 6 * scale, y - 16 * scale, 4 * scale, 8 * scale);
        Ellipse2D.Double rightPupil = new Ellipse2D.Double(x + 2 * scale, y - 16 * scale, 4 * scale, 8 * scale);
        g2d.fill(leftPupil);
        g2d.fill(rightPupil);

        // Antennae
        Path2D.Double leftAntenna = new Path2D.Double();
        leftAntenna.moveTo(x - 5 * scale, y - 20 * scale);
        leftAntenna.curveTo(x - 20 * scale, y - 30 * scale, x - 10 * scale, y - 50 * scale, x - 5 * scale, y - 60 * scale);
        Path2D.Double rightAntenna = new Path2D.Double();
        rightAntenna.moveTo(x + 5 * scale, y - 20 * scale);
        rightAntenna.curveTo(x + 20 * scale, y - 30 * scale, x + 10 * scale, y - 50 * scale, x + 5 * scale, y - 60 * scale);
        g2d.draw(leftAntenna);
        g2d.draw(rightAntenna);

        // Legs (with random movement)
        drawLegsWithRandomMovement(g2d, x, y + 40 * scale, scale);
    }

	private void drawLegsWithRandomMovement(Graphics2D g2d, double x, double y, double scale) {
	    // Random factor for subtle leg movement
	    int randFactor = rand.nextInt(3) - 1; // -1, 0, or 1 for slight movement

	    // Draw front "raptorial" legs for capturing prey
	    for (int side = -1; side <= 1; side += 2) { // -1 for left, +1 for right
	        GeneralPath frontLeg = new GeneralPath();
	        double baseX = x + side * 5 * scale; // Starting X position of the leg
	        double baseY = y; // Starting Y position of the leg

	        // Base segment (femur)
	        double femurX = baseX + side * 10 * scale; // End X of femur segment
	        double femurY = baseY + 5 * scale; // End Y of femur segment
	        frontLeg.moveTo(baseX, baseY);
	        frontLeg.lineTo(femurX, femurY);

	        // Middle segment (tibia) with random movement
	        double tibiaX = femurX + side * 15 * scale + randFactor; // Adding randomness
	        double tibiaY = femurY + 20 * scale + randFactor; // Adding randomness
	        frontLeg.lineTo(tibiaX, tibiaY);

	        // Tip segment (tarsus) slightly curved
	        double tarsusX = tibiaX + side * 10 * scale;
	        double tarsusY = tibiaY - 10 * scale;
	        frontLeg.curveTo(tibiaX, tibiaY, tarsusX, tarsusY - 5 * scale, tarsusX, tarsusY);

	        g2d.draw(frontLeg);
	    }

	    // Draw the other legs for movement
	    for (int i = 1; i <= 2; i++) {
	        for (int side = -1; side <= 1; side += 2) { // -1 for left, +1 for right
	            GeneralPath movingLeg = new GeneralPath();
	            double baseX = x + side * 8 * i * scale; // Adjust base X per leg
	            double baseY = y + 20 * scale; // Base Y for back legs

	            // Single curve to simulate natural leg position
	            movingLeg.moveTo(baseX, baseY);
	            movingLeg.curveTo(baseX + side * 10 * scale, baseY + 10 * scale,
	                              baseX + side * 15 * scale, baseY + 30 * scale,
	                              baseX + side * 5 * scale, baseY + 40 * scale);

	            g2d.draw(movingLeg);
	        }
	    }
	}
   public void update() {
		int mC = rand.nextInt(300);
		
		int uS = rand.nextInt(1300);
		if (uS == 1) {
			swarmed =false;
		}

		if (mC == 0) {
			setMoveCode("Left");
		}
		else if(mC == 1) {
			setMoveCode("Right");

		}
		else if(mC == 2) {
			setMoveCode("Down");
		
		}
		else if(mC == 3) {
			setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}	
		
		if (this.getMoveCode() == "Left") {
			this.x -= 1;

		}else if(this.getMoveCode() == "Right") {
			this.x += 1;

		}
		else if(this.getMoveCode() == "Down") {
			this.y += 1;

		}
		else if(this.getMoveCode() == "Up") {
			this.y -= 1;

		}
		else if(this.getMoveCode() == "LeftUp") {
			this.y -= 1;
			this.x -= 1;


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.x -= 1;
			this.y += 1;

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.x += 1;
			this.y -= 1;
		}
		else if(this.getMoveCode() == "RightDown") {
			this.x += 1;
			this.y += 1;
		}
		
		for (int i = 0;i<Ants.beings.size();i++) {
			double oX = Ants.beings.get(i).getX();
	        double oY = Ants.beings.get(i).getY();
	
	        double dX = this.x - oX;
	        double dY = this.y - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
      	    Color c = Ants.beings.get(i).getC();

	        if(dist < 55 && Ants.beings.get(i)!= this) {
	        	if(swarmed == false) {
		        	if (this.x < Ants.beings.get(i).getX()) {
		        		this.x += 12;
		        	}
		        	
		        	if (this.x > Ants.beings.get(i).getX()) {
		        		this.x -= 12;
		        	}
		        	
		        	if (this.y < Ants.beings.get(i).getY()) {
		        		this.y += 12;
		        	}
		        	
		        	if (this.y > Ants.beings.get(i).getY()) {
		        		this.y -= 12;
		        	}
	        	}else {
	        		if (this.x < Ants.beings.get(i).getX()) {
		        		this.x -= 14;
		        	}
		        	
		        	if (this.x > Ants.beings.get(i).getX()) {
		        		this.x += 14;
		        	}
		        	
		        	if (this.y < Ants.beings.get(i).getY()) {
		        		this.y -= 14;
		        	}
		        	
		        	if (this.y > Ants.beings.get(i).getY()) {
		        		this.y += 14;
		        	}
	        	}
	        }
	        try {
	     
	        
		        if(dist <55 && Ants.beings.get(i)!= this) {
		         double t =rand.nextDouble(5 - (this.scale*4));
		         int t2 = rand.nextInt(100);
		         int t3 = rand.nextInt(50);
		         
		         int swarmedC = rand.nextInt(5);
		         if (swarmedC == 1) {
		        	 swarmed = true;
		         }
		         if (t <= 1 ) {
		        	Ants.beings.remove(i);
		        	if(this.scale < .8) {
			        	this.scale += .03;
		        	}
		         }
		         if (t3 == 1) {
		        	 Food f = new Food(x,y);
		        	 f.setMeat(true);
		        	 f.setEnergy(4);
		        	 Ants.foods.add(f);
		        	 Ants.beings.remove(this);
		         }
		        	
		        }
	        }catch(Exception e) {
	        	
	        }
	        if (this.x < 0) {
				this.x = 0;
			}
			if (this.x > 1000) {
				this.x = 1000;
			}
			if (this.y < 0) {
				this.y = 0;
			}
			if(this.y > 800) {
				this.y = 800;
			}
		}
	}
	  
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public double getScale() {
		return scale;
	}
	public void setScale(double scale) {
		this.scale = scale;
	}


	public boolean isSwarmed() {
		return swarmed;
	}


	public void setSwarmed(boolean swarmed) {
		this.swarmed = swarmed;
	}

}
