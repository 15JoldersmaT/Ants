package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

public class Hill {
	
	private Color c = new Color(255,255,255);
	private int x,y;
	private boolean spawning = true;
	Random rand = new Random();
	
	public Hill(Color c, int x, int y) {
		this.setC(c);
		this.setX(x);
		this.setY(y);
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public Color getC() {
		return c;
	}
	public void setC(Color c) {
		this.c = c;
	}
	
	public void update() {
		int t = rand.nextInt(10);
		
		int t2 = rand.nextInt(15000);
		if (t2 == 1) {
			Ants.hills.remove(this);
		}
		if (this.spawning == true && Ants.beings.size() < 1600) {
			for (int i = 0;i < 1;i++) {
				Being b = new Being(this.c, x, y);
				b.setHomeX(x);
				b.setHomeY(y);
				b.setMode("Leaving");
				Ants.beings.add(b);
			}
			this.spawning = false;
		}
	}
	
	public void draw(Graphics2D g2d) {
		g2d.setColor(this.c);
		 int height = 50 / 2; // You can adjust the height ratio as needed
	        int xPoints[] = {x, x + 50 / 2, x + 50};
	        int yPoints[] = {y, y - height, y};
	        int nPoints = 3;

	        // Draw the triangle as the ant hill
	        g2d.fillPolygon(xPoints, yPoints, nPoints);

	    
	}
	
	public void setSpawn(boolean spawn) {
		this.spawning = spawn;
	}
}
