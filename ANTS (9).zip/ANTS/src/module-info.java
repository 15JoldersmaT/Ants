/**
 * 
 */
/**
 * 
 */
module ANTS {
	requires java.desktop;
}