package pack;

import java.awt.Color;
import java.awt.Graphics2D;

public class Food {
	private int x,y;
	private int energy;
	
	public Food(int x, int y) {
		this.x = x;
		this.y = y;
		this.energy = 3;
	}
	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	
	public void draw(Graphics2D g2d) {
		g2d.setColor(Color.GREEN);
	    g2d.drawRect(x, y, 15, 15); // Draw the outline of a rectangle with x=10, y=10, width=200, and height=100
	    
	}

}
