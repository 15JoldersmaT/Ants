package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import java.awt.Graphics2D;
public class Being {
	Random rand = new Random();
	private int x,y;
	private int moveTimer = 100;
	private String mode = "Leaving";
	private Color c = new Color(255,255,255);
	private int homeX, homeY;
	//id of scent
	private int sID = 0;
	private int id = 0;
	//scent strength
	private int sStrength = 1000;
	public static int gM = 0;
	public Being(Color c, int x, int y) {
		this.c = c;
		this.x = x;
		this.y = y;
		this.id = gM;
		gM+=1;
	}
	
	public void draw(Graphics2D g2d) {
		g2d.setColor(this.c);
	    g2d.fillRect(x, y, 10, 10); // Draw the outline of a rectangle with x=10, y=10, width=200, and height=100
	    g2d.setColor(Color.WHITE);
	    g2d.drawRect(x, y, 10, 10); // Draw the outline of a rectangle with x=10, y=10, width=200, and height=100
	    
	}
	public void update() {
		int t2 = rand.nextInt(5000);
		if (t2 == 1) {
			Ants.beings.remove(this);
		}
		int t = rand.nextInt(2);
		if (t==1 && this.mode == "Returning" && this.sStrength > 0) {
			Scent s = new Scent(this.c,this.x,this.y,this.mode,this.id);
			s.setStrength(this.sStrength);
			s.setMode("Leaving");
			Ants.scents.add(s);
			this.sStrength -= 10;
		}
		if(this.sStrength <= 0) {
			this.mode = "Returning";
		}
		for (int i = 0;i < Ants.scents.size();i++) {
			double oX = Ants.scents.get(i).getX();
            double oY = Ants.scents.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < (Ants.scents.get(i).getStrength()/10)  && Ants.scents.get(i).getId() != this.getId() && Ants.scents.get(i).getC() == this.c ) {
            	if (this.mode == "Leaving") {
                	this.sID = Ants.scents.get(i).getId();
                }
            	if( Ants.scents.get(i).getId() == this.sID) {
	            	if (this.x < Ants.scents.get(i).getX()) {
	            		this.x += 4;
	            	}
	            	
	            	if (this.x > Ants.scents.get(i).getX()) {
	            		this.x -= 4;
	            	}
	            	
	            	if (this.y < Ants.scents.get(i).getY()) {
	            		this.y += 4;
	            	}
	            	
	            	if (this.y > Ants.scents.get(i).getY()) {
	            		this.y -= 4;
	            	}
            	}
            }
		}
		
		this.x += rand.nextInt(7)-3;
		this.y += rand.nextInt(7)-3;

		for (int i = 0;i < Ants.foods.size();i++) {
			double oX = Ants.foods.get(i).getX();
            double oY = Ants.foods.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 5 && this.mode == "Leaving" ) {
            	if (this.x < Ants.foods.get(i).getX()) {
            		this.x += 2;
            	}
            	
            	if (this.x > Ants.foods.get(i).getX()) {
            		this.x -= 2;
            	}
            	
            	if (this.y < Ants.foods.get(i).getY()) {
            		this.y += 2;
            	}
            	
            	if (this.y > Ants.foods.get(i).getY()) {
            		this.y -= 2;
            	}
            }
            if(Ants.foods.get(i).getEnergy() <= 0) {
            	Ants.foods.remove(Ants.foods.get(i));
            	Hill h = new Hill(this.c,this.x,this.y);
            	Ants.hills.add(h);
            }
            if(dist < 5 && this.mode == "Leaving" && Ants.foods.get(i).getEnergy() > 0) {
            	this.mode = "Returning";
            	Ants.foods.get(i).setEnergy(Ants.foods.get(i).getEnergy() - 1);
            
            	
            }
		}
		
		for (int i = 0;i < Ants.hills.size();i++) {
			double oX = Ants.hills.get(i).getX();
            double oY = Ants.hills.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 5 && this.mode == "Returning" && Ants.hills.get(i).getC() == this.c) {
            	this.mode = "Leaving";
            	this.sStrength = 1000;
            	Ants.hills.get(i).setSpawn(true);
            }
            
            
		}
		
		if (this.mode == "Returning") {
			if (this.x < homeX) {
	    		this.x += 5;
	    	}
	    	
	    	if (this.x >homeX) {
	    		this.x -= 5;
	    	}
	    	
	    	if (this.y < homeY) {
	    		this.y += 5;
	    	}
	    	
	    	if (this.y >homeY) {
	    		this.y -= 5;
	    	}
		}
		
		if (this.x < 0) {
			this.x = 0;
		}
		if (this.x > 1000) {
			this.x = 1000;
		}
		if (this.y < 0) {
			this.y = 0;
		}
		if(this.y > 800) {
			this.y = 800;
		}
		
	}
	public int getMoveTimer() {
		return moveTimer;
	}
	public void setMoveTimer(int moveTimer) {
		this.moveTimer = moveTimer;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}

	public int getHomeX() {
		return homeX;
	}

	public void setHomeX(int homeX) {
		this.homeX = homeX;
	}

	public int getHomeY() {
		return homeY;
	}

	public void setHomeY(int homeY) {
		this.homeY = homeY;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getsStrength() {
		return sStrength;
	}

	public void setsStrength(int sStrength) {
		this.sStrength = sStrength;
	}

	public int getsID() {
		return sID;
	}

	public void setsID(int sID) {
		this.sID = sID;
	}
}
