package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import java.awt.Graphics2D;
public class Being {
	Random rand = new Random();
	private int x,y;
	private int moveTimer = 100;
	private String mode = "Leaving";
	private Color c = new Color(255,255,255);
	private int homeX, homeY;
	private String moveCode ="Left";
	//id of scent
	private int sID = 0;
	private int id = 0;
	//scent strength
	private int sStrength = 300;
	public static int gM = 0;
	public Being(Color c, int x, int y) {
		this.c = c;
		this.x = x;
		this.y = y;
		this.id = gM;
		gM+=1;
	}
	
	public void draw(Graphics2D g2d) {
		Color cn = new Color(this.c.getRed()+65,this.c.getGreen()+65, this.c.getBlue()+65);
		g2d.setColor(cn);
		double size = .4;
		int headSize = (int)(10 * size);
        int bodyWidth = (int)(20 * size);
        int bodyHeight = (int)(10 * size);
        int rearWidth = (int)(15 * size);
        int rearHeight = (int)(15 * size);
        int legLength = (int)(10 * size);
        int strokeWidth = (int)(2 * size);

        // Set the color for the ant

        // Draw the body parts of the ant
        // Head
        g2d.fill(new Ellipse2D.Double(x, y, headSize, headSize));
        // Body
        g2d.fill(new Ellipse2D.Double(x + headSize - size, y + size, bodyWidth, bodyHeight));
        // Rear
        g2d.fill(new Ellipse2D.Double(x + headSize + bodyWidth - 2*size, y, rearWidth, rearHeight));

        // Legs
        g2d.setStroke(new BasicStroke(strokeWidth));
        for (int i = 0; i < 3; i++) {
            int legX = x + (int)(5 * size) + (i * (int)(8 * size));
            g2d.drawLine(legX, y + headSize / 2, legX, y + headSize / 2 + legLength);
            g2d.drawLine(legX, y + headSize / 2, legX, y + headSize / 2 - legLength);
        }
	    
	}
	public void update() {
		int t2 = rand.nextInt(5000);
		if (t2 == 1) {
			Ants.beings.remove(this);
		}
		int t = rand.nextInt(1);
		if (t<51 && this.mode == "Returning" && this.sStrength > 0) {
			Scent s = new Scent(this.c,this.x,this.y,this.mode,this.id);
			s.setStrength(this.sStrength/2);
			s.setMode("Leaving");
			Ants.scents.add(s);
			this.sStrength -= 10;
		}
		if (t==2 && this.mode == "Leaving" && this.sStrength > 0) {
			//Scent s = new Scent(this.c,this.x,this.y,this.mode,this.id);
			//s.setStrength(this.sStrength);
			//s.setMode("Returning");
			//s.setStrength(5);
			//Ants.scents.add(s);
			//this.sStrength -= 10;
		}
		if(this.sStrength <= 0) {
			if(this.mode == "Leaving") {
				this.mode = "Returning";
			}else {
				int t4 = rand.nextInt(250);
				if(t4 == 1) {
	        		Food f = new Food(this.x,this.y);
	        		f.setEnergy(1);
	        		f.setMeat(true);
	        		Ants.foods.add(f);
					Ants.beings.remove(this);
				}
			}
		}
		for (int i = 0;i < Ants.scents.size();i++) {
			double oX = Ants.scents.get(i).getX();
            double oY = Ants.scents.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < (Ants.scents.get(i).getStrength()/6)  && Ants.scents.get(i).getId() != this.getId() && Ants.scents.get(i).getC() == this.c ) {
            	if (this.mode == "Leaving") {
                	this.sID = Ants.scents.get(i).getId();
                }
            		if( Ants.scents.get(i).getId() == this.sID) {
		            	if (this.x < Ants.scents.get(i).getX()) {
		            		this.x += 5;
		            	}
		            	
		            	if (this.x > Ants.scents.get(i).getX()) {
		            		this.x -= 5;
		            	}
		            	
		            	if (this.y < Ants.scents.get(i).getY()) {
		            		this.y += 5;
		            	}
		            	
		            	if (this.y > Ants.scents.get(i).getY()) {
		            		this.y -= 5;
		            	}
            		}
            	
            	
            }
		}
		
		int mC = rand.nextInt(300);
		if (mC == 0) {
			moveCode = "Left";
		}
		else if(mC == 1) {
			moveCode = "Right";

		}
		else if(mC == 2) {
			moveCode = "Down";
		
		}
		else if(mC == 3) {
			moveCode = "Up";

		}
		else if(mC == 4) {
			moveCode = "LeftUp";

		}
		else if(mC == 5) {
			moveCode = "LeftDown";

		}
		else if(mC == 6) {
			moveCode = "RightUp";

		}
		else if(mC == 7) {
			moveCode = "RightDown";

		}	
		if (this.moveCode == "Left") {
			this.x -= 1;

		}else if(this.moveCode == "Right") {
			this.x += 1;

		}
		else if(this.moveCode == "Down") {
			this.y += 1;

		}
		else if(this.moveCode == "Up") {
			this.y -=1;

		}
		else if(this.moveCode == "LeftUp") {
			this.y -= 1;
			this.x -= 1;


		}
		else if(this.moveCode == "LeftDown") {
			this.x -= 1;
			this.y += 1;

		}
		
		else if(this.moveCode == "RightUp") {
			this.x += 1;
			this.y -= 1;
		}
		else if(this.moveCode == "RightDown") {
			this.x += 1;
			this.y += 1;
		}
		

		for (int i = 0;i < Ants.foods.size();i++) {
			double oX = Ants.foods.get(i).getX();
            double oY = Ants.foods.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 35 && this.mode == "Leaving" ) {
            	if (this.x < Ants.foods.get(i).getX()) {
            		this.x += 12;
            	}
            	
            	if (this.x > Ants.foods.get(i).getX()) {
            		this.x -= 12;
            	}
            	
            	if (this.y < Ants.foods.get(i).getY()) {
            		this.y += 12;
            	}
            	
            	if (this.y > Ants.foods.get(i).getY()) {
            		this.y -= 12;
            	}
            }
            try {
            if(Ants.foods.get(i).getEnergy() <= 0) {
            	Ants.foods.remove(Ants.foods.get(i));
            	if(Ants.foods.get(i).isMeat() == false) {
            		Hill h = new Hill(this.c,this.x,this.y);
            		Ants.hills.add(h);
            	}
            }
            
            if(dist <10 && this.mode == "Leaving" && Ants.foods.get(i).getEnergy() > 0) {
            	if(Ants.foods.get(i).getEnergy() <= 0 && Ants.foods.get(i).isMeat() == false) {
                	Ants.foods.remove(Ants.foods.get(i));
                	Hill h = new Hill(this.c,this.x,this.y);
                	Ants.hills.add(h);
                }
            	this.mode = "Returning";
            	Ants.foods.get(i).setEnergy(Ants.foods.get(i).getEnergy() - 1);
            	this.sStrength = 300;

            	if(Ants.foods.get(i).isMeat() == true) {
            		Ants.foods.remove(i);
            	}
            
            	
            }
            }catch(Exception e) {
            	
            }
		}
		
		for (int i = 0;i < Ants.hills.size();i++) {
			double oX = Ants.hills.get(i).getX();
            double oY = Ants.hills.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 5 && this.mode == "Returning" && Ants.hills.get(i).getC() == this.c) {
            	this.mode = "Leaving";
            	this.sStrength = 300;
            	Ants.hills.get(i).setSpawn(true);
            }else if (dist < 5 && Ants.hills.get(i).getC() != this.c) {
            	Ants.hills.remove(Ants.hills.get(i));
            }
            
            
		}
		
		for (int i = 0;i < Ants.beings.size();i++) {
			double oX = Ants.beings.get(i).getX();
            double oY = Ants.beings.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 5 && Ants.beings.get(i).c != this.c) {
            	int t3 = rand.nextInt(2);
            	if(t3 == 1) {
            		Ants.beings.remove(Ants.beings.get(i));
            		Food f = new Food(this.x,this.y);
            		f.setEnergy(1);
            		f.setMeat(true);
            		Ants.foods.add(f);
            	}
            }
            
            
		}
		
		if (this.mode == "Returning") {
			if (this.x < homeX) {
	    		this.x += 5;
	    	}
	    	
	    	if (this.x >homeX) {
	    		this.x -= 5;
	    	}
	    	
	    	if (this.y < homeY) {
	    		this.y += 5;
	    	}
	    	
	    	if (this.y >homeY) {
	    		this.y -= 5;
	    	}
		}
		
		if (this.x < 0) {
			this.x = 0;
		}
		if (this.x > 1000) {
			this.x = 1000;
		}
		if (this.y < 0) {
			this.y = 0;
		}
		if(this.y > 800) {
			this.y = 800;
		}
		
	}
	public int getMoveTimer() {
		return moveTimer;
	}
	public void setMoveTimer(int moveTimer) {
		this.moveTimer = moveTimer;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}

	public int getHomeX() {
		return homeX;
	}

	public void setHomeX(int homeX) {
		this.homeX = homeX;
	}

	public int getHomeY() {
		return homeY;
	}

	public void setHomeY(int homeY) {
		this.homeY = homeY;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getsStrength() {
		return sStrength;
	}

	public void setsStrength(int sStrength) {
		this.sStrength = sStrength;
	}

	public int getsID() {
		return sID;
	}

	public void setsID(int sID) {
		this.sID = sID;
	}

	public String getMoveCode() {
		return moveCode;
	}

	public void setMoveCode(String moveCode) {
		this.moveCode = moveCode;
	}
}
